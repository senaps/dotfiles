from setuptools import setup, find_packages

setup(name='$Name$',
      version='$version$',
      description='$description$',
      url='$url$',
      author='$author$',
      author_email='$author_email$',
      license='$license$',
      packages=find_packages(),
      include_package_data=True,
      package_data={
                '$name$':['*.json'],
                },
       zip_safe=False)
